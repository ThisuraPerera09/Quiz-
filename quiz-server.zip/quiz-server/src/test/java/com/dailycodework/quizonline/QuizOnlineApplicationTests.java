package com.dailycodework.quizonline;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuizOnlineApplicationTests {

    @Test
    void contextLoads() {
    }

}
